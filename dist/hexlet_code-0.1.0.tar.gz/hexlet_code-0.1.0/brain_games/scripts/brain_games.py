#!/usr/bin/env python3
print('Welcome to the Brain Games!')

def main():
	pass

if __name__ == '__main__':
	main()

